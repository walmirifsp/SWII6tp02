﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Estoque.Models
{
	public class CategoriaDoProduto
	{
		public int Id { get; set; }

		public string Nome { get; set; }

		public string Descricao { get; set; }
	}
}